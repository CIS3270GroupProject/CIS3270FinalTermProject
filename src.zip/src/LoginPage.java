import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

import java.awt.GridBagLayout;
import java.awt.CardLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.Color;

public class LoginPage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private final Action action = new SwingAction();

	/**
	 * Launch the application.
	 */
	
	Connection conn =  null;
	OraclePreparedStatement pst = null;
	OracleResultSet rs = null;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage frame = new LoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 592, 325);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLoginPage = new JLabel("Login Page");
		lblLoginPage.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblLoginPage.setBounds(199, 3, 141, 39);
		contentPane.add(lblLoginPage);
		
		JLabel lblLogin = new JLabel("User Name:");
		lblLogin.setBounds(93, 63, 112, 26);
		contentPane.add(lblLogin);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(93, 132, 100, 26);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(226, 57, 186, 39);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(226, 126, 186, 39);
		contentPane.add(passwordField);
		
		JButton btnLoginNow = new JButton("Login Now");
		btnLoginNow.setForeground(Color.RED);
		btnLoginNow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conn = ConnectionClass.dbconnect;
				try {
					String query = "select * from Login_Table where User_Name = ? and password = ?";
					pst = (OraclePreparedStatement) conn.prepareStatement(query);
					pst.setString(1, textField.getText());
					pst.setString(2, passwordField.getText());
					rs = (OracleResultSet) pst.executeQuery();
					
					if(rs.next()) {
						JOptionPane.showMessageDialog(null, "username & password are correct");
					}
					else {
						JOptionPane.showMessageDialog(null, "Invalid credentials" );
					}
					pst.close();
					rs.close();
				}
				catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnLoginNow.setAction(action);
		btnLoginNow.setBounds(199, 198, 162, 35);
		contentPane.add(btnLoginNow);
	}
	
}
