
public class MainMenu{
	private boolean choice;
	
	public void RegisteredMember(boolean choice){
		System.out.println("Are you already a member?");
		if(choice) {
			//go to LoginPage
		}
		else {
			//go to Registration
		}
	}
}
