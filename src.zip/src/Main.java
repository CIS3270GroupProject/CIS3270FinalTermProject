import java.util.Scanner;
import java.util.*;

public class Main {
	public static void main(String[]args) {
		
		MainMenu mainmenu = new MainMenu();
	}
		
		
	
