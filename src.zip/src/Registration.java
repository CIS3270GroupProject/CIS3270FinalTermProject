import java.util.Scanner;

public class Registration {
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String street;
	private String city;
	private String state;
	private int zipCode;
	private String username;
	private String email;
	private String preferredPhoneNumber;
	private String ssn;
	private String securityQuestion;
	private String securityQuestionAnswer;
	
	private static Scanner input = new Scanner(System.in);
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		System.out.println("username: ");
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("password: ");
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		System.out.println("first name: ");
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		System.out.println("last name: ");
		this.lastName = lastName;
		
	}

	public String getPreferredPhoneNumber() {
		return preferredPhoneNumber;
	}

	public void setPreferredPhoneNumber(String preferredPhoneNumber) {
		System.out.println("phone number: ");
		this.preferredPhoneNumber = preferredPhoneNumber;
	}
	
	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		System.out.println("street: ");
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		System.out.println("city: ");
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		System.out.println("state: ");
		this.state = state;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		System.out.println("zipcode: ");
		this.zipCode = zipCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		System.out.println("email: ");
		this.email = email;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		System.out.println("social security number: ");
		this.ssn = ssn;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		System.out.println("choose security question: ");
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityQuestionAnswer() {
		return securityQuestionAnswer;
	}

	public void setSecurityQuestionAnswer(String securityQuestionAnswer) {
		System.out.println("answer: ");
		this.securityQuestionAnswer = securityQuestionAnswer;
	}
}
