package userLevelOfAccess;

public class Customer extends User {

}
