package userLevelOfAccess;

public class Admin extends User {

}
