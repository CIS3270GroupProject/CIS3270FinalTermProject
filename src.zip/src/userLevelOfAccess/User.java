package userLevelOfAccess;

public class User {

}
