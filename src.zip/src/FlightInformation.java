import java.util.ArrayList;

public class FlightInformation {
	private ArrayList<String>flightList = new ArrayList<String>();
	
	public void addFlight(String flight) {
		flightList.add(flight);
	}
	public void printFlightAvailibility() {
		System.out.println("There are " + flightList.size() + " flights available.");
		for(int i = 0; i < flightList.size(); i ++) {
			System.out.println((i + 1) + ". " + flightList.get(i));
		}
	}
	public void modifyFlight(int flightNumber, String newFlight) {
		flightList.set(flightNumber, newFlight);
	}
	public void removeFlight(int flightNumber1) {
		String  flightNumber2 = flightList.get(flightNumber1);
		flightList.remove(flightNumber1);
		
	}
}
